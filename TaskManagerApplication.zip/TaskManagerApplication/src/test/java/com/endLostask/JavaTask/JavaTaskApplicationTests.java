package com.endLostask.JavaTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
