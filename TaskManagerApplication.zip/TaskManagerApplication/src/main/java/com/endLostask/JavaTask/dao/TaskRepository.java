package com.endLostask.JavaTask.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.endLostask.JavaTask.vo.Task;

public interface TaskRepository extends JpaRepository<Task, Long> {}

