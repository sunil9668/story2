package com.endLostask.JavaTask.rest;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import com.endLostask.JavaTask.vo.Task;

@Controller
public class TaskWebSocketController {

    private final SimpMessagingTemplate messagingTemplate;

    public TaskWebSocketController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    public void broadcastTaskUpdate(Task task) {
        messagingTemplate.convertAndSend("/topic/tasks", task);
    }
}
