package com.endLostask.JavaTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaTaskApplication.class, args);
	}

}
